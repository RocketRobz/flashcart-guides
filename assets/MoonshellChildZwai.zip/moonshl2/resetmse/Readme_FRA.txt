Afin de pouvoir profiter de la fonction de redémarrage, vous devez ajouter le fichier nds correspondant à votre linker dans ce dossier.

J'ai abandonné la méthode complexe de Moonshell. La structure MSE ne tient plus dans la VRAM.

Désormais, c'est un fichier nds ordinaire qui est lancé. Ce fichier nds doit avoir un nom comme ceci «nom_du_linker.nds».

ex:
SCDS.nds => pour SuperCard DS One
CEVO.nds => pour CycloDS
DLMS.nds => pour DSLink
R4TF.nds => pour R4

~Traduit par Supercarte