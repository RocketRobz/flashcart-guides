
Ce dossier contient les applications pour l'onglet "Accessoires".
On peut y mettre jusqu'à 5 applications nds.
Vous pouvez effacer tout ce qu'il y a à l'intérieur mais veuillez ne pas effacer le dossier /launch.