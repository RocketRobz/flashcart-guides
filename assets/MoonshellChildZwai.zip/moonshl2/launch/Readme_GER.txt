Diese Daten dienen dem "Accessories"-Reiter des File Launcher.
Es k�nnen bis zu 5 .NDS-Daten in diesem Ordner abgelegt werden.
Es k�nnen Inhalte des Ordners gel�scht werden, der Ordner selbst sollte allerdings erhalten bleiben.

~�bersetzt von Falco