
Permet de d'associer une application externe à un nom d'extension de fichier.
Veuillez ne pas supprimer ce dossier même si vous n'utilisez pas cette fonctionnalité.

Le nom de l'extension est définie par le nom du fichier lui-même.
Par exemple, si le fichier ipk.nds se trouve dans ce dossier, ipk.nds démarrera dès qu'on lancera un fichier ayant l'extension ipk. Lorsque l'extension est déjà associée à un lecteur interne, c'est l'application de ce dossier qui sera executée en priorité (mp3.nds, jpg.nds, etc).

Si l'application n'est pas compatible avec cette fonctionnalité, elle s'executera mais le fichier associé ne sera pas ouvert par celle-ci.
Par exemple, si vous placez ReinMoon.nds dans ce dossier et que vous le renommez sav.nds, lorsque vous ouvrirez un fichier sav, ReinMoon se lancera sans tenir compte du fichier sav sélectionné.

Créer une application compatible avec l'association par l'extension n'est pas difficile. (enfin, j'ai essayé de faire simple.)
Référez-vous au fichier "moonshl2_extlink_for_developer.txt" (prévu pour plus tard) pour en savoir plus.
La façon de retourner à Moonshell 2 depuis un homebrew y sera décrite aussi. (Ça c'est peut-être un peu délicat.)

