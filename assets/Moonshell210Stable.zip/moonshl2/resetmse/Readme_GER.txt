Sollte eine Firmware Reset NDS-Datei passend zu Ihrer Flashcard in dem Ordner vorhanden sein,
so haben Sie die m�glichkeit, aus MoonShell2 direkt in Ihre Firmware zur�ck zu springen.

Die arbeiten an der komplexen Struktur von MoonShell wurden eingestellt. Die MSE Struktur wird nicht im VRAM behalten.
Es wird lediglich die Datei 'flashcartname.nds' aufgerufen. Der Name der Flashcard sollte sich an der eindeutigen DLDI ID orientieren (zB M3DS.nds f�r M3 DS Real).

Beispiele:
SCDS.nds => f�r SuperCard DS One
CEVO.nds => f�r CycloDS
DLMS.nds => f�r DSLink
R4TF.nds => f�r R4

~�bersetzt von Falco