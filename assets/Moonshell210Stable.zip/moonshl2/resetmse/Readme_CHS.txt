﻿各烧录卡对应的复位文件放入本文件夹，可以在系统菜单中退回烧录卡界面。

MoonShell的复杂机制不复存在。没有在VRAM中保留MSE的结构。
会启动'烧录卡名.nds'这样文件名的NDS文件。烧录卡名请使用DLDI的识别ID指定。

例：
SCDS.nds => SuperCard DS One用
CEVO.nds => CycloDS用
DLMS.nds => DSLink用
R4TF.nds => R4用
